import java.io.*;
import java.net.*;

class TCPClient {
	public static void main(String argv[]) throws Exception {
		String sentence;

		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(
				System.in));
		sentence = inFromUser.readLine();

		if (sentence.equals("CONNECT")) {
			Socket clientSocket = new Socket("192.168.1.3", 6789);
			System.out.println("Connected!");

			// To output the sentence written from client to server
			DataOutputStream outToServer = new DataOutputStream(
					clientSocket.getOutputStream());
			while (!(sentence.equals("stop"))) {
				BufferedReader inFromServer = new BufferedReader(
						new InputStreamReader(clientSocket.getInputStream()));
				if (inFromUser.ready()) {
					sentence = inFromUser.readLine();
					outToServer.writeBytes(sentence + '\n');
					System.out.println("Sentence sent to server");
				} else if (inFromServer.ready()) {
					sentence = inFromServer.readLine();
					System.out.println("FROM SERVER: " + sentence);
				}
			}

			clientSocket.close();
		}

	}
}