import java.io.*;
import java.net.*;

class TCPServer {

	public static void main(String argv[]) throws Exception {
		String sentence;

		ServerSocket welcomeSocket = new ServerSocket(6789);
		Socket connectionSocket = welcomeSocket.accept();

		// Get input from client
		BufferedReader inFromClient = new BufferedReader(new InputStreamReader(
				connectionSocket.getInputStream()));

		sentence = inFromClient.readLine();
		BufferedReader inFromServer = new BufferedReader(new InputStreamReader(
				System.in));
		while (!sentence.equals("stop")) {
			DataOutputStream outToClient = new DataOutputStream(
					connectionSocket.getOutputStream());
			if (inFromServer.ready()) {
				sentence = inFromServer.readLine();
				outToClient.writeBytes(sentence + '\n');
				System.out.println("Sentence sent to client");
			} else if (inFromClient.ready()) {
				sentence = inFromClient.readLine();
				System.out.println("FROM CLIENT: " + sentence);
			}
		}
		connectionSocket.close();
		welcomeSocket.close();

	}
}
